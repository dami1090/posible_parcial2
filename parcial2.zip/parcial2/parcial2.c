#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"
#include "destinatario.h"
#include "parcial2.h"

int parserDestinatario(FILE* pFile, ArrayList* pArrayListDestinatario,char dire[])
{
    int retorno=0;
    char auxName[100], auxMail[200];
    eDestinatario* desti;
    eDestinatario* aux;
    printf("dire1\n");
    pFile=fopen(dire,"r");
    printf("dire2\n");
    fscanf(pFile,"%[^,],%[^\n]\n",auxName,auxMail);
    while(!feof(pFile))
    {
        fscanf(pFile,"%[^,],%[^\n]\n",auxName,auxMail);
        aux=desti_new();
        if(aux!=NULL)
        {
            printf("dire3\n");
            desti=aux;
            setterName(desti,auxName);
            setterMail(desti,auxMail);
            pArrayListDestinatario->add(pArrayListDestinatario,desti);

        }
        else
        {
            printf("\nNo hay mas espacio\n");
        }
        retorno=1;
    }
    printf("dire4\n");
     fclose(pFile);
    return retorno;
}



