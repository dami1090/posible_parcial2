typedef struct
{
    char nombre[50];
    char mail[200];
}eDestinatario;

void cargar(char mensaje[],ArrayList* lista,FILE* archi);
eDestinatario* desti_new(void);
int setterName(eDestinatario* this, char* name);
int setterMail(eDestinatario* this, char* mail);
void destinatario_print(eDestinatario* this);
void mostrarMuchos(ArrayList* this);
int depurar(ArrayList* lista,ArrayList* listaNegra,ArrayList* listaDepurada);
void guardar(ArrayList* listaDepurada,char ruta[]);
