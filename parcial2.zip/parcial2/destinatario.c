#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"
#include "destinatario.h"
#include "parcial2.h"

void cargar(char mensaje[],ArrayList* lista,FILE* archi)
{
    int aux;
    char dire[200];
    printf("%s",mensaje);
    setbuf(stdin,NULL);
    scanf("%[^\n]",dire);
    //archi=fopen(dire,"r");
    aux=parserDestinatario(archi,lista,dire);
    if(aux==0)
    {
        printf("\nNo existe el archivo\n");
    }

    return;
}

eDestinatario* desti_new(void)
{

    eDestinatario* returnAux;
    eDestinatario* aux;
    aux = (eDestinatario*)calloc(1,sizeof(eDestinatario));
    if(aux!=NULL)
    {
        returnAux=aux;
    }
    return returnAux;

}

int setterName(eDestinatario* this, char* name)
{
    strcpy(this->nombre,name);
    return 0;

}

int setterMail(eDestinatario* this, char* mail)
{
    strcpy(this->mail,mail);
    return 0;

}

void destinatario_print(eDestinatario* this)
{
    printf("%s--%s\n",this->nombre,this->mail);
}

void mostrarMuchos(ArrayList* this)
{
    int i;
    void* aux;
    for(i=0; i<this->len(this); i++)
    {
        /*if(!(i%250))
        {
            system("pause");
        }*/

        aux=(eDestinatario*)this->get(this,i);
        destinatario_print(aux);
    }
    return;
}

int depurar(ArrayList* lista,ArrayList* listaNegra,ArrayList* listaDepurada)
{
    int retorno=0;
    int i,j,flag=1;
    eDestinatario* mail1;
    eDestinatario* mail2;
    if(lista!=NULL && listaNegra!=NULL && listaDepurada!=NULL)
    {
        for(i=0; i<lista->len(lista); i++)
        {
            for(j=0; j<listaNegra->len(listaNegra); j++)
            {
                mail1=(eDestinatario*)lista->get(lista,i);
                mail2=(eDestinatario*)listaNegra->get(listaNegra,j);
                if(strcmp(mail1->mail,mail2->mail)==0)
                {
                    flag=0;
                    break;
                }
                else
                {
                    flag=1;
                }
            }
            if(flag==1)
            {
                listaDepurada->add(listaDepurada,lista->get(lista,i));
            }
        }
        retorno = 1;
    }
    return retorno;
}

void guardar(ArrayList* listaDepurada,char ruta[])
{
    FILE *fp;
    eDestinatario* auxElement;
    int i;
    fp = fopen ( ruta, "w+" );
    if(fp!=NULL)
    {
        for(i=0;i<listaDepurada->len(listaDepurada);i++)
        {
            auxElement=(eDestinatario*)listaDepurada->get(listaDepurada,i);
            fprintf(fp,"%s,",auxElement->nombre);
            fprintf(fp," %s\n",auxElement->mail);
        }
    }
    else
    {
        printf("\nNo pudo crearse el archivo");
    }
    fclose ( fp );

 	return;
}
