

int parserDestinatario(FILE* pFile, ArrayList* pArrayListDestinatario,char[]);
